library(testthat)
library(rkf)

test_check("rkf")
